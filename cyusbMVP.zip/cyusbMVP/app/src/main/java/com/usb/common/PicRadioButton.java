package com.usb.common;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatRadioButton;

import com.usb.model.R;


public class PicRadioButton extends AppCompatRadioButton {

    public PicRadioButton(Context context) {
        super(context);
    }

    public PicRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
         Drawable drawableTop,drawableLeft,drawableRight,drawableBottom;
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.PicRadioButton);//获取我们定义的属性
        int attr = typedArray.getIndex(0);
        int attrCount = typedArray.getIndexCount();
//        drawable = typedArray.getDrawable(attr);
        drawableLeft = typedArray.getDrawable(R.styleable.PicRadioButton_drawableLeft);
        drawableTop = typedArray.getDrawable(R.styleable.PicRadioButton_drawableTop);
        drawableRight = typedArray.getDrawable(R.styleable.PicRadioButton_drawableRight);
        drawableBottom = typedArray.getDrawable(R.styleable.PicRadioButton_drawableBottom);
        drawableLeft.setBounds(0, 0, 80, 80);
        drawableTop.setBounds(0, 0, 80, 80);
        drawableRight.setBounds(0, 0, 80, 80);
        drawableBottom.setBounds(0, 0, 80, 80);
        setCompoundDrawables(drawableTop, drawableTop, drawableRight, drawableBottom);

    }


}
